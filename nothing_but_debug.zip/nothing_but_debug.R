
setwd("your working directory")

rm(list = ls())

J <- 10
data_input <- list(J = J)

# run stan -----------------------------
library(rstan)

rstan_options(auto_write = TRUE)
estMCMC <- stan_model(file= 'model.stan')

set.seed(13137)
stan_inits <- list(list(guess = rep(0.1, times = J),
                        slip = rep(0.1, times = J)))

# MCMC
fitMCMC <- sampling(estMCMC,
                    data = data_input,
                    init = stan_inits,
                    iter = 10,
                    chains = 1)
